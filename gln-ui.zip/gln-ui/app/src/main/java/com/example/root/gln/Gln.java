package com.example.root.gln;

/**
 * Created by root on 12/2/17.
 */

public class Gln {
    //static final String HOST = "http://192.168.0.4:5000"; //Mysore PG
    static final String HOST = "http://192.168.43.245:5000"; //Redmi
    //static final String HOST = "http://192.168.43.245:5000"; //Moto g4 plus
    //static final String HOST = "http://192.168.0.25:5000"; //Bangalore PG
    static final String TAG = "GLN";
}
